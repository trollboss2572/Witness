package com.example.actualwitness.GamePrep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import com.example.actualwitness.R;
import com.google.android.material.snackbar.Snackbar;

public class CharacterSelect extends AppCompatActivity {
    RadioGroup radGroup;
    Button butt;
    String CharChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_select);
        radGroup = findViewById(R.id.Characters);
        butt =findViewById(R.id.button_first);
        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(CharChoice == null)) {
                    Intent intent = new Intent(CharacterSelect.this, CharacterConfirm.class);
                    intent.putExtra("Choice", CharChoice);
                    startActivity(intent);
                }
                Snackbar myS = Snackbar.make(v, "You must choose a character", 500);
                myS.show();
            }
        });
    }
    public void checkButton(View v)
    {
        int radioID = radGroup.getCheckedRadioButtonId();
        switch(radioID)
        {
            case R.id.BlakeButton:
            {
                CharChoice = "Blake";
                break;
            }
            case R.id.MortimerButton:
            {
                CharChoice = "Mortimer";
                break;
            }
            case R.id.LabrousseButton:
            {
                CharChoice = "Labrousse";
                break;
            }
            case R.id.NasirButton:
            {
                CharChoice = "Nasir";
                break;
            }
        }
    }
}