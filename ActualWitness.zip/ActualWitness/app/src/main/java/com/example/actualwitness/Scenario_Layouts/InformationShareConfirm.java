package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.actualwitness.R;

public class InformationShareConfirm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information_share_confirm);
        Intent intent = getIntent();
        String Choice = intent.getStringExtra("Choice");
        int ScenarioID = intent.getIntExtra("ScenarioID", -1);
        Button b = findViewById(R.id.ToIntroduction);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(InformationShareConfirm.this, IntroductionGeneral.class);
                newIntent.putExtra("ScenarioID", ScenarioID);
                newIntent.putExtra("Choice", Choice);
                startActivity(newIntent);
            }
        });
    }
}