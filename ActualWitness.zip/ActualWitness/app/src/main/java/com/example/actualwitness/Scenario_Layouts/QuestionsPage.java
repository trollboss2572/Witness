package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;
import com.example.actualwitness.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class QuestionsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions_page);
        Intent intent = this.getIntent();
        int ScenarioID = intent.getIntExtra("ScenarioID", -1);
        String Choice = intent.getStringExtra("Choice");
        String Question_prompt = getResources().getStringArray(R.array.Question_Prompts)[ScenarioID];
        String Questions = getResources().getStringArray(R.array.Questions)[ScenarioID];
        TextView t = findViewById(R.id.QuestionPrompt);
        t.setText(Question_prompt + "\n \n" + Questions);
        Button b = findViewById(R.id.ToSolutions);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent (QuestionsPage.this, SolutionsPage.class);
                newIntent.putExtra("ScenarioID", ScenarioID);
                newIntent.putExtra("Choice", Choice);
                startActivity(newIntent);
            }
        });

    }
}