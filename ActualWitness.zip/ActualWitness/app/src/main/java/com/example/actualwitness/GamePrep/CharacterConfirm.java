package com.example.actualwitness.GamePrep;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.actualwitness.Game.ScenarioPick;
import com.example.actualwitness.R;

public class CharacterConfirm extends AppCompatActivity {
    TextView charName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_characterconfirm);
        Intent intent = this.getIntent();
        String character = intent.getStringExtra("Choice");
        TextView t = findViewById(R.id.textView4);
        t.setText(character);
        findViewById(R.id.Confirm_butt).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CharacterConfirm.this, ScenarioPick.class);
                intent.putExtra("Choice", character);
                startActivity(intent);
            }
        });
    }
}