package com.example.actualwitness.Game;

import android.widget.Button;
import android.widget.TextView;

public class ScenarioModel {
    String t;
    int position;
    public String getT()
    {
        return t;
    }
    public int getPosition(){return position;}
    public ScenarioModel(String s, int pos)
    {
        position = pos;
        t = s;
    }

}
