package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;
import com.example.actualwitness.R;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class IntroductionGeneral extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction_general);
        Intent intent = getIntent();
        int ScenarioID = intent.getIntExtra("ScenarioID", -1);
        String Choice = intent.getStringExtra("Choice");
        String [] array_List = getResources().getStringArray(R.array.Introduction);
        TextView S_int = findViewById(R.id.Scenario_Intro);
        S_int.setText(array_List[ScenarioID]);
        Button but = findViewById(R.id.To_Character_Info);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(IntroductionGeneral.this, CharacterInfo.class);
                newIntent.putExtra("Choice", Choice);
                newIntent.putExtra("ScenarioID", ScenarioID);
                startActivity(newIntent);
            }
        });
    }
}