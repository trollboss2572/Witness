package com.example.actualwitness.Game;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
