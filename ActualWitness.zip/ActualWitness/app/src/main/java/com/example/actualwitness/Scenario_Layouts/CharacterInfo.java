package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;
import com.example.actualwitness.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CharacterInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_info);
        Intent intent = this.getIntent();
        String Choice = intent.getStringExtra("Choice");
        int ScenarioID = intent.getIntExtra("ScenarioID", -1);
        String PlayerInfo = getPlayerInfo(Choice, ScenarioID);
        TextView t = findViewById(R.id.PlayerInfo);
        t.setText(PlayerInfo);
        Button questions = findViewById(R.id.Questions);
        questions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent NewIntent = new Intent(CharacterInfo.this, QuestionsPage.class);
                NewIntent.putExtra("ScenarioID", ScenarioID);
                NewIntent.putExtra("Choice", Choice);
                startActivity(NewIntent);
            }
        });
    }
    private String getPlayerInfo(String Character, int ID)
    {
        String ret = null;
        if (Character.equals("Blake"))
        {
            String [] array = getResources().getStringArray(R.array.Blake_Info);
            ret = array[ID];
        }
        else if (Character.equals("Mortimer"))
        {
            String [] array = getResources().getStringArray(R.array.Mortimer_Info);
            ret = array[ID];
        }
        else if (Character.equals("Nasir"))
        {
            String [] array = getResources().getStringArray(R.array.Nasir_Info);
            ret = array[ID];
        }
        else if (Character.equals("Labrousse"))
        {
            String [] array = getResources().getStringArray(R.array.Labrousse_Info);
            ret = array[ID];
        }
        return ret;
    }

}