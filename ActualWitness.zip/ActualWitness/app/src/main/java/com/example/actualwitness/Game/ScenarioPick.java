package com.example.actualwitness.Game;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.actualwitness.R;
import com.example.actualwitness.Scenario_Layouts.Confirmation_of_Scenario_General;

import java.util.ArrayList;

public class ScenarioPick extends AppCompatActivity implements RecyclerViewInterface {
    ArrayList<ScenarioModel> scenarioPickModels = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scenario_pick);
        RecyclerView rv = findViewById(R.id.scenario_pick_recycler);
        setScenarioPickModels();
        ScenarioPickViewAdapter adapter = new ScenarioPickViewAdapter(this, scenarioPickModels, this);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setScenarioPickModels(){
        String[] ScenarioNames = getResources().getStringArray(R.array.Scenario_Names);

        for(int i = 0; i< ScenarioNames.length; i++)
        {
            scenarioPickModels.add(new ScenarioModel(ScenarioNames[i], i));
        }
    }

    @Override
    public void onItemClick(int position) {
        Intent this_intent = getIntent();
        String character = this_intent.getStringExtra("Choice");
        Intent intent = new Intent(ScenarioPick.this, Confirmation_of_Scenario_General.class);
        intent.putExtra("Choice", character);
        intent.putExtra("ScenarioID", scenarioPickModels.get(position).getPosition());
        startActivity(intent);
    }
}