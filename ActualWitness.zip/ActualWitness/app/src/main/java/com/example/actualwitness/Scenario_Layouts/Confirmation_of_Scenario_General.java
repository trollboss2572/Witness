package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.actualwitness.R;

public class Confirmation_of_Scenario_General extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation_of_scenario_general);
        Intent intent = getIntent();
        String Choice = intent.getStringExtra("Choice");
        int Scenario_ID = intent.getIntExtra("ScenarioID", -1);
        TextView Scenario = findViewById(R.id.Scenario_Name);
        String [] Scenario_Names = getResources().getStringArray(R.array.Scenario_Names);
        Scenario.setText(Scenario_Names[Scenario_ID]);
        Button but = findViewById(R.id.confirm_butt_for_Scenario_confirm);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent NewIntent = new Intent (Confirmation_of_Scenario_General.this, InformationShareConfirm.class);
                NewIntent.putExtra("Choice", Choice);
                NewIntent.putExtra("ScenarioID", Scenario_ID);
                startActivity(NewIntent);
            }
        });

    }
}