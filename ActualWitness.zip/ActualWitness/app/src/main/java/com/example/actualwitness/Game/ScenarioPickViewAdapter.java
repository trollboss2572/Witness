package com.example.actualwitness.Game;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.example.actualwitness.R.layout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.actualwitness.R;

import java.util.ArrayList;

public class ScenarioPickViewAdapter extends RecyclerView.Adapter<ScenarioPickViewAdapter.MyViewHolder> {
    private final RecyclerViewInterface recyclerViewInterface;
    Context context;
    ArrayList<ScenarioModel> scenarioModels;

    public ScenarioPickViewAdapter(Context c, ArrayList<ScenarioModel> Amogus, RecyclerViewInterface recyclerViewInterface)
    {
        this.context = c;
        scenarioModels = Amogus;
        this.recyclerViewInterface = recyclerViewInterface;
    }


    @NonNull
    @Override
    public ScenarioPickViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(layout.recycler_row, parent, false);
        return new ScenarioPickViewAdapter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull ScenarioPickViewAdapter.MyViewHolder holder, int position) {
        holder.t.setText((CharSequence) scenarioModels.get(position).getT());
    }

    @Override
    public int getItemCount() {
        return scenarioModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView t;
        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface)
        {
            super(itemView);
            t = itemView.findViewById(R.id.Scenar_Name);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (recyclerViewInterface != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION)
                        {
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
}
