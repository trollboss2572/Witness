package com.example.actualwitness.Scenario_Layouts;

import androidx.appcompat.app.AppCompatActivity;

import com.example.actualwitness.Game.ScenarioPick;
import com.example.actualwitness.MenuPages.MainMenu;
import com.example.actualwitness.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SolutionsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solutions_page);
        Intent intent = this.getIntent();
        int ScenarioID = intent.getIntExtra("ScenarioID", -1);
        String Choice = intent.getStringExtra("Choice");
        String Solution = getResources().getStringArray(R.array.Solutions)[ScenarioID];
        String Solution_Prompt = getResources().getStringArray(R.array.Solution_Text)[ScenarioID];
        TextView t = findViewById(R.id.PlayerReadSolution);
        t.setText(Solution + "\n \n" + Solution_Prompt);
        Button b = findViewById(R.id.BackToMenu);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(SolutionsPage.this, ScenarioPick.class);
                newIntent.putExtra("Choice", Choice);
                startActivity(newIntent);
            }
        });
    }
}